/*
 *  FileException.h
 *  pvalue
 *
 *  Created by Jean-Stéphane Varré on 02/07/07.
 *  Copyright 2007 LIFL-USTL-INRIA. All rights reserved.
 *
 */

#ifndef __FILEEXCEPTION__
#define __FILEEXCEPTION__

#include <iostream>

using namespace std;

class FileException { };

#endif

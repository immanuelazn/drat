library(testthat)
library(motifmatchr)

test_check("motifmatchr")
